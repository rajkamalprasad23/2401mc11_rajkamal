#include "types.h"
#include "user.h"

int
main(void)
{
  char *p;
  int physical_address;
  int invalid_address = 0x70000000;

  printf(1, "\n===== VIRTUAL TO PHYSICAL TEST =====\n");

  // Allocate one page
  p = sbrk(4096);

  if(p == (char*)-1){
    printf(1, "Memory allocation failed\n");
    exit();
  }

  // Trigger lazy allocation by accessing the page
  p[0] = 'A';

  printf(1, "\nVirtual address: %x\n", (uint)p);

  // Translate a valid virtual address
  physical_address = vtop((int)p);

  if(physical_address != -1)
    printf(1, "Physical address: %x\n", physical_address);
  else
    printf(1, "Translation failed for valid address\n");

  // Test an invalid/unmapped address
  printf(1, "\nTesting invalid address: %x\n", invalid_address);

  physical_address = vtop(invalid_address);

  if(physical_address == -1)
    printf(1, "Correctly detected invalid/unmapped address\n");
  else
    printf(1, "Unexpected translation: %x\n", physical_address);

  printf(1, "\n===== TEST COMPLETED =====\n");

  exit();
}
