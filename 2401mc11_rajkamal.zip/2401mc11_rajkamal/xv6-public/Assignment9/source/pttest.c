#include "types.h"
#include "user.h"

int
main(void)
{
  char *p;

  printf(1, "=== Initial page table ===\n");
  vmprint();

  printf(1, "\n=== Calling sbrk(4 * 4096) ===\n");
  p = sbrk(4 * 4096);

  printf(1, "\n=== Page table after sbrk ===\n");
  vmprint();

  printf(1, "\n=== Touching 4 new pages ===\n");

  p[0] = 'A';
  p[4096] = 'B';
  p[8192] = 'C';
  p[12288] = 'D';

  printf(1, "\n=== Page table after touching pages ===\n");
  vmprint();

  printf(1, "\n=== Page faults: %d ===\n", getpgfaults());

  exit();
}
