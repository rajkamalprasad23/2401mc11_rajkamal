#include "types.h"
#include "user.h"

int
main(void)
{
  char *p;
  int i;

  printf(1, "=== Lazy allocation test ===\n");

  p = sbrk(16 * 4096);
  if(p == (char*)-1){
    printf(1, "sbrk failed\n");
    exit();
  }

  printf(1, "Allocated virtual space for 16 pages\n");

  for(i = 0; i < 5; i++){
    p[i * 4096] = 'A' + i;
  }

  printf(1, "Touched 5 pages\n");
  printf(1, "Page faults handled: %d\n", getpgfaults());

  exit();
}
