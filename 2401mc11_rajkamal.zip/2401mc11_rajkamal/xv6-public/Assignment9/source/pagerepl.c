
#include "types.h"
#include "user.h"

#define MAXREF 30
#define MAXFRAME 5

int refs[] = {
  7, 0, 1, 2, 0, 3, 0, 4, 2, 3,
  0, 3, 2, 1, 2, 0, 1, 7, 0, 1
};

int nref = 20;

void
printframes(int frames[], int n)
{
  int i;

  printf(1, "[ ");
  for(i = 0; i < n; i++){
    if(frames[i] == -1)
      printf(1, "- ");
    else
      printf(1, "%d ", frames[i]);
  }
  printf(1, "]");
}

int
runfifo(int nf, int verbose)
{
  int frames[MAXFRAME];
  int i, j, next, hit, faults;

  for(i = 0; i < nf; i++)
    frames[i] = -1;

  next = 0;
  faults = 0;

  if(verbose)
    printf(1, "\nFIFO with %d frames:\n", nf);

  for(i = 0; i < nref; i++){
    hit = 0;

    for(j = 0; j < nf; j++){
      if(frames[j] == refs[i]){
        hit = 1;
        break;
      }
    }

    if(!hit){
      frames[next] = refs[i];
      next = (next + 1) % nf;
      faults++;
    }

    if(verbose){
      printf(1, "Page %d: ", refs[i]);
      printframes(frames, nf);
      printf(1, " %s\n", hit ? "HIT" : "FAULT");
    }
  }

  if(verbose)
    printf(1, "FIFO total page faults = %d\n", faults);

  return faults;
}

int
runlru(int nf, int verbose)
{
  int frames[MAXFRAME];
  int last[MAXFRAME];
  int i, j, victim, hit, faults;

  for(i = 0; i < nf; i++){
    frames[i] = -1;
    last[i] = -1;
  }

  faults = 0;

  if(verbose)
    printf(1, "\nLRU with %d frames:\n", nf);

  for(i = 0; i < nref; i++){
    hit = 0;
    victim = -1;

    for(j = 0; j < nf; j++){
      if(frames[j] == refs[i]){
        hit = 1;
        last[j] = i;
        break;
      }
    }

    if(!hit){
      for(j = 0; j < nf; j++){
        if(frames[j] == -1){
          victim = j;
          break;
        }
      }

      if(victim == -1){
        victim = 0;
        for(j = 1; j < nf; j++){
          if(last[j] < last[victim])
            victim = j;
        }
      }

      frames[victim] = refs[i];
      last[victim] = i;
      faults++;
    }

    if(verbose){
      printf(1, "Page %d: ", refs[i]);
      printframes(frames, nf);
      printf(1, " %s\n", hit ? "HIT" : "FAULT");
    }
  }

  if(verbose)
    printf(1, "LRU total page faults = %d\n", faults);

  return faults;
}

int
main(void)
{
  int nf, fifo, lru;

  printf(1, "Reference string: ");
  for(int i = 0; i < nref; i++)
    printf(1, "%d ", refs[i]);
  printf(1, "\n");

  fifo = runfifo(3, 1);
  lru = runlru(3, 1);

  printf(1, "\n=== Comparison for 3, 4 and 5 frames ===\n");
  printf(1, "Frames  FIFO faults  FIFO hit%%  LRU faults  LRU hit%%\n");

  for(nf = 3; nf <= 5; nf++){
    fifo = runfifo(nf, 0);
    lru = runlru(nf, 0);

    printf(1, "  %d        %d          %d%%         %d          %d%%\n",
           nf, fifo, ((nref - fifo) * 100) / nref,
           lru, ((nref - lru) * 100) / nref);
  }

  exit();
}
