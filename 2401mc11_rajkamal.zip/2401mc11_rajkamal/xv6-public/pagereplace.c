
#include "types.h"
#include "user.h"

#define N 20
#define MAXF 5

int ref[N] = {
  7, 0, 1, 2, 0, 3, 0, 4, 2, 3,
  0, 3, 2, 1, 2, 0, 1, 7, 0, 1
};

int
simulate(int algorithm, int capacity, int display)
{
  int frames[MAXF];
  int last_used[MAXF];
  int i, j, k, victim, next, found;
  int hits = 0, faults = 0;

  for(i = 0; i < capacity; i++){
    frames[i] = -1;
    last_used[i] = -1;
  }

  next = 0;

  if(display){
    if(algorithm == 0)
      printf(1, "\nFIFO - %d Frames\n", capacity);
    else if(algorithm == 1)
      printf(1, "\nLRU - %d Frames\n", capacity);
    else
      printf(1, "\nOPTIMAL - %d Frames\n", capacity);

    printf(1, "Page\tFrames\t\tResult\n");
  }

  for(i = 0; i < N; i++){
    found = 0;

    // Check whether page is already present
    for(j = 0; j < capacity; j++){
      if(frames[j] == ref[i]){
        found = 1;
        hits++;
        last_used[j] = i;
        break;
      }
    }

    if(!found){
      faults++;

      // Find an empty frame first
      victim = -1;

      for(j = 0; j < capacity; j++){
        if(frames[j] == -1){
          victim = j;
          break;
        }
      }

      // All frames occupied: choose replacement
      if(victim == -1){

        if(algorithm == 0){
          // FIFO
          victim = next;
          next = (next + 1) % capacity;
        }
        else if(algorithm == 1){
          // LRU
          victim = 0;
          for(j = 1; j < capacity; j++){
            if(last_used[j] < last_used[victim])
              victim = j;
          }
        }
        else{
          // Optimal
          int farthest = -1;

          for(j = 0; j < capacity; j++){
            int distance = N + 1;

            for(k = i + 1; k < N; k++){
              if(ref[k] == frames[j]){
                distance = k;
                break;
              }
            }

            if(distance > farthest){
              farthest = distance;
              victim = j;
            }
          }
        }
      }

      frames[victim] = ref[i];
      last_used[victim] = i;
    }

    if(display){
      printf(1, "%d\t", ref[i]);

      for(j = 0; j < capacity; j++){
        if(frames[j] == -1)
          printf(1, "- ");
        else
          printf(1, "%d ", frames[j]);
      }

      if(found)
        printf(1, "\tHIT\n");
      else
        printf(1, "\tFAULT\n");
    }
  }

  if(display){
    printf(1, "Total Hits: %d\n", hits);
    printf(1, "Total Faults: %d\n", faults);
    printf(1, "Hit Ratio: %d/%d = %d%%\n",
           hits, N, hits * 100 / N);
    printf(1, "Fault Ratio: %d/%d = %d%%\n",
           faults, N, faults * 100 / N);
  }

  return faults;
}

int
main(void)
{
  int algorithm, capacity;
  int faults, hits;

  printf(1, "\n===== PAGE REPLACEMENT SIMULATION =====\n");

  for(algorithm = 0; algorithm < 3; algorithm++){
    for(capacity = 3; capacity <= 5; capacity++){
      simulate(algorithm, capacity, 1);
    }
  }

  printf(1, "\n===== COMPARISON TABLE =====\n");
  printf(1, "Algorithm Frames Hits Faults Hit%% Fault%%\n");

  for(algorithm = 0; algorithm < 3; algorithm++){
    for(capacity = 3; capacity <= 5; capacity++){
      faults = simulate(algorithm, capacity, 0);
      hits = N - faults;

      if(algorithm == 0)
        printf(1, "FIFO      ");
      else if(algorithm == 1)
        printf(1, "LRU       ");
      else
        printf(1, "OPTIMAL   ");

      printf(1, "%d       %d    %d     %d%%    %d%%\n",
             capacity, hits, faults,
             hits * 100 / N, faults * 100 / N);
    }
  }

  printf(1, "\n===== SIMULATION COMPLETED =====\n");
  exit();
}
