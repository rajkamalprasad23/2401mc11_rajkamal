#include "types.h"
#include "user.h"

int
main(void)
{
  printf(1, "=== Initial page table ===\n");
  vmprint();

  printf(1, "\n=== Calling sbrk(4 * 4096) ===\n");
  sbrk(4 * 4096);

  printf(1, "\n=== Page table after sbrk ===\n");
  vmprint();

  exit();
}
