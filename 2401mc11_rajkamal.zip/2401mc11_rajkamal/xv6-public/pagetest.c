#include "types.h"
#include "user.h"

int
main(void)
{
  char *p;

  printf(1, "\n===== PAGE PROTECTION TEST =====\n");

  // Allocate one page
  p = sbrk(4096);

  if(p == (char*)-1){
    printf(1, "Memory allocation failed\n");
    exit();
  }

  // Trigger lazy allocation
  p[0] = 'A';

  printf(1, "\n--- Before protection ---\n");
  if(pageinfo((int)p) < 0)
    printf(1, "Could not retrieve page information\n");

  // Remove write permission
  if(setreadonly((int)p) < 0){
    printf(1, "Failed to set page read-only\n");
    exit();
  }

  printf(1, "\n--- After protection ---\n");
  pageinfo((int)p);

  printf(1, "\nAttempting to write to read-only page...\n");

  // This should cause a protection fault
  p[0] = 'B';

  printf(1, "ERROR: Write unexpectedly succeeded!\n");

  exit();
}
