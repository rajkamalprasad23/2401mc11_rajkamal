#include "types.h"
#include "stat.h"
#include "user.h"

int global_var = 100;

int
main(void)
{
  int before, after, va, pa;
  int pid;
  before = freepages();
  printf(1, "Initial free pages: %d\n", before);

   sbrk(10 * 4096);

  after = freepages();

  printf(1, "Free pages after sbrk: %d\n", after);

  va = (int)&global_var;
  pa = va2pa(va);

  printf(1, "Global variable VA: %x\n", va);
  printf(1, "Global variable PA: %x\n", pa);

  printf(1, "Invalid address translation: %d\n",
         va2pa(0x7fffffff));

  pid = fork();

  if(pid < 0) {
    printf(1, "Fork failed\n");
    exit();
  }

  if(pid == 0) {
    printf(1, "Child VA: %x\n", (int)&global_var);
    printf(1, "Child PA: %x\n", va2pa((int)&global_var));
    printf(1, "Free pages after fork: %d\n", freepages());
    exit();
  }

  printf(1, "Parent VA: %x\n", (int)&global_var);
  printf(1, "Parent PA: %x\n", va2pa((int)&global_var));
  printf(1, "Free pages after fork: %d\n", freepages());

  wait();

  printf(1, "Free pages after child exit: %d\n", freepages());

  printf(1, "Done\n");
  exit();
}

