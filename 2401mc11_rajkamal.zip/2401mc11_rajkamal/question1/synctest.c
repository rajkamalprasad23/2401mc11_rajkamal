#include "types.h"
#include "stat.h"
#include "user.h"

int main(void){
    sem_init(0,1);
    sem_init(1,0);
    sem_init(2,0);

    int pid1 = fork();

    if(pid1==0){
        for(int i=0; i<5; i++){
            sem_wait(0);
            printf(1, "a");
            sem_post(1);
        }
        exit();
    }
    int pid2 = fork();

    if(pid2 == 0){
        for(int i=0; i<5; i++){
            sem_wait(1);
            printf(1, "b");
            sem_post(2);
        }
        exit();
    }

    int pid3 = fork();

    if(pid3 == 0){
        for(int i=0; i<5;i++){
            sem_wait(2);
            printf(1, "c");
            sem_post(0);
        }
        exit();
    }
    wait();
    wait();
    wait();
	
    printf(1,"\ndone\n");
    exit();
}

