#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  
  addr = myproc()->sz;

  if(n > 0){
    myproc()->sz += n;
  } else if(n < 0){
    if(growproc(n) < 0)
      return -1;
  }

  return addr;
}

int
sys_sleep(void){
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
// Q1: System call wrapper for vmprint.
int
sys_vmprint(void)
{
  return vmprint();
}
int
sys_getpgfaults(void)
{
  return myproc()->pgfault_count;
}
// Assignment 10: Display physical memory statistics
int
sys_memstats(void)
{
  uint allocated, freed, available;

  getmemstats(&allocated, &freed, &available);

  cprintf("\n===== Physical Memory Statistics =====\n");
  cprintf("Total allocated pages : %d\n", allocated);
  cprintf("Total freed pages     : %d\n", freed);
  cprintf("Currently allocated   : %d\n", allocated - freed);
  cprintf("Available pages       : %d\n", available);
  cprintf("======================================\n");

  return 0;
}
// Assignment 10: Virtual to Physical Address Translation
int
sys_vtop(void)
{
  int virtual_address;

  if(argint(0, &virtual_address) < 0)
    return -1;

  return vtop(myproc()->pgdir, (uint)virtual_address);
}
// Assignment 10: Display page information
int
sys_pageinfo(void)
{
  int virtual_address;

  if(argint(0, &virtual_address) < 0)
    return -1;

  return pageinfo(myproc()->pgdir, (uint)virtual_address);
}

// Assignment 10: Set page as read-only
int
sys_setreadonly(void)
{
  int virtual_address;

  if(argint(0, &virtual_address) < 0)
    return -1;

  return setreadonly(myproc()->pgdir, (uint)virtual_address);
}
int
sys_sem_init(void)
{
  int id, value;

  if(argint(0, &id) < 0 || argint(1, &value) < 0)
    return -1;

  return sem_init(id, value);
}

int
sys_sem_wait(void)
{
  int id;

  if(argint(0, &id) < 0)
    return -1;

  return sem_wait(id);
}

int
sys_sem_post(void)
{
  int id;

  if(argint(0, &id) < 0)
    return -1;

  return sem_post(id);
}
int
sys_freepages(void)
{
  return getfreepages();
}

int
sys_va2pa(void)
{
  int va;

  if(argint(0, &va) < 0)
    return -1;

  return getpa(myproc()->pgdir, (uint)va);
}
