#include "types.h"
#include "stat.h"
#include "user.h"

int global_var = 100;

int main(void){
  int before, after, va, pa;
  int pid;
  before = freepages();
  printf(1, "initial free pages: %d\n", before);

   sbrk(10 * 4096);

  after = freepages();

  printf(1, "Free pages after sbrk: %d\n", after);

  va = (int)&global_var;
  pa = va2pa(va);

  printf(1, "global var va: %x\n", va);
  printf(1, "global var va: %x\n", pa);

  printf(1, "Invalid address translation: %d\n",
         va2pa(0x7fffffff));

  pid = fork();

  if(pid < 0) {
    printf(1, "Fork failed\n");
    exit();
  }

  if(pid == 0) {
    printf(1, "child va: %x\n", (int)&global_var);
    printf(1, "child pa: %x\n", va2pa((int)&global_var));
    printf(1, "free pages after fork: %d\n", freepages());
    exit();
  }

  printf(1, "parent va: %x\n", (int)&global_var);
  printf(1, "parent pa: %x\n", va2pa((int)&global_var));
  printf(1, "free pages after fork: %d\n", freepages());

  wait();

  printf(1, "free pages after child exit: %d\n", freepages());

  printf(1, "\ndone\n");
  exit();
}

