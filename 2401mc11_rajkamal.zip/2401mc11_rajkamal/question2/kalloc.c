
// Physical memory allocator, intended to allocate
// memory for user processes, kernel stacks, page table pages,
// and pipe buffers. Allocates 4096-byte pages.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"

void freerange(void *vstart, void *vend);
extern char end[];

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  int use_lock;
  struct run *freelist;
  int free_pages;
  uint total_allocated;
  uint total_freed;
} kmem;

void
kinit1(void *vstart, void *vend)
{
  initlock(&kmem.lock, "kmem");
  kmem.use_lock = 0;
  kmem.free_pages = 0;
  kmem.total_allocated = 0;
  kmem.total_freed = 0;
  freerange(vstart, vend);
}

void
kinit2(void *vstart, void *vend)
{
  freerange(vstart, vend);
  kmem.use_lock = 1;
}

void
freerange(void *vstart, void *vend)
{
  char *p;
  p = (char*)PGROUNDUP((uint)vstart);
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
    kfree(p);
}

void
kfree(char *v)
{
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
    panic("kfree");

  memset(v, 1, PGSIZE);

  if(kmem.use_lock)
    acquire(&kmem.lock);

  r = (struct run*)v;
  r->next = kmem.freelist;
  kmem.freelist = r;
  kmem.free_pages++;
  kmem.total_freed++;

  if(kmem.use_lock)
    release(&kmem.lock);
}

char*
kalloc(void)
{
  struct run *r;

  if(kmem.use_lock)
    acquire(&kmem.lock);

  r = kmem.freelist;
  if(r) {
    kmem.freelist = r->next;
    kmem.free_pages--;
    kmem.total_allocated++;
  }

  if(kmem.use_lock)
    release(&kmem.lock);

  return (char*)r;
}

void
getmemstats(uint *allocated, uint *freed, uint *available)
{
  struct run *r;
  uint count = 0;

  acquire(&kmem.lock);

  *allocated = kmem.total_allocated;
  *freed = kmem.total_freed;

  for(r = kmem.freelist; r; r = r->next)
    count++;

  *available = count;

  release(&kmem.lock);
}

int
getfreepages(void)
{
  int count;

  acquire(&kmem.lock);
  count = kmem.free_pages;
  release(&kmem.lock);

  return count;
}

